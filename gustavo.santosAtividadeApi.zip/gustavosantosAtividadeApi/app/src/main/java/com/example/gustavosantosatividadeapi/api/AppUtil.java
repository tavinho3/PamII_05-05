package com.example.gustavosantosatividadeapi.api;

public class AppUtil {
    public static final String TAG = "etim";
}
