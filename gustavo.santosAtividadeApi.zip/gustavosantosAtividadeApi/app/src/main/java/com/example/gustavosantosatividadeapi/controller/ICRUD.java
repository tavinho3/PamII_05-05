package com.example.gustavosantosatividadeapi.controller;

public interface ICRUD<T> {
    public boolean incluir(T obj);
    public boolean alterar(T obj);
    public boolean deletar(T obj);
    public boolean listar(T obj);

}
