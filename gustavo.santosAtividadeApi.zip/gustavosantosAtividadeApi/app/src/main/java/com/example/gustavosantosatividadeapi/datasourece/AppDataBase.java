package com.example.gustavosantosatividadeapi.datasourece;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.gustavosantosatividadeapi.api.AppUtil;
import com.example.gustavosantosatividadeapi.datamodel.ClienteDataModel;

public class AppDataBase extends SQLiteOpenHelper{
    public static final String NAME = "atividade_GustavoSantos.sqlite";
    public static int version = 4;
    SQLiteDatabase db;

    public AppDataBase(Context context){
        super(context, NAME, null, version);
        db = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i(AppUtil.TAG, "Criando a tabela " + ClienteDataModel.TABELA);
        db.execSQL(ClienteDataModel.criarTabela());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE " + ClienteDataModel.TABELA);

    }
}
