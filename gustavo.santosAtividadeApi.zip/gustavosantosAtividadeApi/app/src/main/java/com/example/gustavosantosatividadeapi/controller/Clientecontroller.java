package com.example.gustavosantosatividadeapi.controller;

import android.content.Context;

import com.example.gustavosantosatividadeapi.datasourece.AppDataBase;

public class Clientecontroller extends AppDataBase {
    public Clientecontroller(Context context){
        super(context);
    }
}
